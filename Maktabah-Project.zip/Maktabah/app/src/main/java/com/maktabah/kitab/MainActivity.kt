package com.maktabah.kitab

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Typeface
import org.json.JSONObject
import org.json.JSONArray

data class PdfBook(val name: String, val uri: Uri)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("maktabah", MODE_PRIVATE) }
    private var treeUri: Uri? = null
    private val books = mutableListOf<PdfBook>()
    private val categories = mutableListOf<String>()
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private var query = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        treeUri = prefs.getString("tree", null)?.let { Uri.parse(it) }
        loadCategories()
        buildUi()
        if (treeUri != null) scan()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 22, 20, 20)
            setBackgroundColor(0xFFF7F5EF.toInt())
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "مكتبة  |  MAKTABAH"
            textSize = 25f
            setTextColor(0xFF244B37.toInt())
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)
        root.addView(TextView(this).apply {
            text = "Perpustakaan PDF kitab pribadi"
            textSize = 14f
            setTextColor(0xFF666666.toInt())
            setPadding(0, 4, 0, 16)
        })

        button("Pilih folder tempat PDF kitab disimpan") { chooseFolder() }
        button("Pindai ulang folder") { scan() }
        button("Buat folder / subfolder kategori") { addCategory() }

        val search = EditText(this).apply {
            hint = "Cari judul kitab..."
            singleLine = true
            setPadding(12, 8, 12, 8)
        }
        root.addView(search)
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                query = s?.toString().orEmpty()
                renderBooks()
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        status = TextView(this).apply {
            textSize = 13f
            setTextColor(0xFF555555.toInt())
            setPadding(0, 12, 0, 12)
        }
        root.addView(status)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        updateStatus()
        renderBooks()
    }

    private fun button(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF315D45.toInt()))
            setOnClickListener { action() }
        }
        root.addView(b, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 7 })
    }

    private fun chooseFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        startActivityForResult(i, 101)
    }

    @Deprecated("Deprecated in Android API but retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            try { contentResolver.takePersistableUriPermission(uri, flags) } catch (_: Exception) {}
            treeUri = uri
            prefs.edit().putString("tree", uri.toString()).apply()
            scan()
        }
    }

    private fun scan() {
        val tree = treeUri
        if (tree == null) {
            status.text = "Pilih folder penyimpanan PDF terlebih dahulu."
            return
        }
        books.clear()
        try {
            val rootId = DocumentsContract.getTreeDocumentId(tree)
            scanFolder(tree, rootId, 0)
            updateStatus()
            renderBooks()
        } catch (e: Exception) {
            status.text = "Folder tidak dapat dipindai: ${e.localizedMessage ?: "izin akses tidak tersedia"}"
        }
    }

    private fun scanFolder(tree: Uri, parentId: String, depth: Int) {
        if (depth > 12) return
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        contentResolver.query(childrenUri, projection, null, null, null)?.use { c ->
            val idCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeCol = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
            while (c.moveToNext()) {
                val id = c.getString(idCol)
                val name = c.getString(nameCol) ?: "Tanpa nama"
                val mime = c.getString(mimeCol)
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    scanFolder(tree, id, depth + 1)
                } else if (mime == "application/pdf" || name.lowercase().endsWith(".pdf")) {
                    val docUri = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                    books.add(PdfBook(name, docUri))
                }
            }
        }
    }

    private fun updateStatus() {
        status.text = "Ditemukan ${books.size} PDF  •  ${categories.size} kategori"
    }

    private fun renderBooks() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val filtered = books.filter { it.name.contains(query, true) }
        if (filtered.isEmpty()) {
            list.addView(TextView(this).apply {
                text = if (books.isEmpty()) "Belum ada PDF. Pilih folder lalu pindai." else "Kitab tidak ditemukan."
                textSize = 15f
                setPadding(4, 16, 4, 16)
            })
            return
        }
        filtered.forEach { book ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(14, 12, 14, 12)
                setBackgroundColor(0xFFFFFFFF.toInt())
            }
            val name = TextView(this).apply {
                text = "📕  ${book.name}"
                textSize = 15f
                setTextColor(0xFF222222.toInt())
                typeface = Typeface.DEFAULT_BOLD
            }
            card.addView(name)
            val cat = getBookCategory(book.uri.toString())
            val categoryText = TextView(this).apply {
                text = "Kategori: ${cat.ifBlank { "Belum ditentukan" }}"
                textSize = 12f
                setTextColor(0xFF666666.toInt())
                setPadding(0, 5, 0, 5)
            }
            card.addView(categoryText)
            val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val open = Button(this).apply {
                text = "Baca PDF"
                isAllCaps = false
                setOnClickListener { openPdf(book) }
            }
            val organize = Button(this).apply {
                text = "Atur kategori"
                isAllCaps = false
                setOnClickListener { chooseCategory(book, categoryText) }
            }
            actions.addView(open, LinearLayout.LayoutParams(0, -2, 1f))
            actions.addView(organize, LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(actions)
            list.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        }
    }

    private fun openPdf(book: PdfBook) {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(book.uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "Tidak ditemukan aplikasi pembaca PDF.", Toast.LENGTH_LONG).show()
        }
    }

    private fun addCategory() {
        val input = EditText(this).apply {
            hint = "Contoh: Fikih/Muamalah/Qiradh"
            setText("Fikih/")
        }
        AlertDialog.Builder(this)
            .setTitle("Buat folder kategori")
            .setMessage("Gunakan tanda / untuk membuat subfolder.")
            .setView(input)
            .setNegativeButton("Batal", null)
            .setPositiveButton("Simpan") { _, _ ->
                val value = input.text.toString().trim().trim('/')
                if (value.isNotBlank() && !categories.contains(value)) {
                    categories.add(value)
                    saveCategories()
                    updateStatus()
                    renderBooks()
                }
            }.show()
    }

    private fun chooseCategory(book: PdfBook, label: TextView) {
        val suggested = suggestCategory(book.name)
        val options = (listOf("Belum ditentukan", "Saran otomatis: $suggested") + categories).distinct()
        AlertDialog.Builder(this)
            .setTitle("Pilih kategori kitab")
            .setItems(options.toTypedArray()) { _, which ->
                val selected = when (which) {
                    0 -> ""
                    1 -> suggested
                    else -> options[which]
                }
                saveBookCategory(book.uri.toString(), selected)
                label.text = "Kategori: ${selected.ifBlank { "Belum ditentukan" }}"
            }.setNegativeButton("Batal", null).show()
    }

    private fun suggestCategory(filename: String): String {
        val s = filename.lowercase()
        val rules = listOf(
            "Ushul Fikih" to listOf("ushul", "أصول"),
            "Fikih" to listOf("fiqh", "fikih", "فقه", "منهاج", "الإقناع", "المجموع"),
            "Tafsir" to listOf("tafsir", "تفسير", "قرطبي", "طبري"),
            "Hadis" to listOf("hadis", "hadith", "حديث", "بخاري", "مسلم"),
            "Nahwu dan Sharaf" to listOf("nahwu", "sharaf", "نحو", "صرف", "ألفية", "أجرومية"),
            "Akidah" to listOf("aqidah", "akidah", "عقيدة", "توحيد"),
            "Tarikh" to listOf("tarikh", "sejarah", "تاريخ", "سيرة")
        )
        return rules.firstOrNull { rule -> rule.second.any { s.contains(it) } }?.first ?: "Lainnya"
    }

    private fun loadCategories() {
        categories.clear()
        val raw = prefs.getString("categories", "[]") ?: "[]"
        try {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) categories.add(a.getString(i))
        } catch (_: Exception) {}
        if (categories.isEmpty()) {
            categories.addAll(listOf("Fikih", "Ushul Fikih", "Tafsir", "Hadis", "Nahwu dan Sharaf", "Akidah", "Tarikh", "Lainnya"))
            saveCategories()
        }
    }

    private fun saveCategories() {
        val a = JSONArray()
        categories.forEach { a.put(it) }
        prefs.edit().putString("categories", a.toString()).apply()
    }

    private fun getBookCategory(uri: String): String =
        try { JSONObject(prefs.getString("book_categories", "{}") ?: "{}").optString(uri, "") }
        catch (_: Exception) { "" }

    private fun saveBookCategory(uri: String, category: String) {
        val obj = try { JSONObject(prefs.getString("book_categories", "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        obj.put(uri, category)
        prefs.edit().putString("book_categories", obj.toString()).apply()
    }
}
